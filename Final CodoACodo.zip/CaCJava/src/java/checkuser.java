import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet(urlPatterns = {"/checkuser"})
public class checkuser extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Persistencia base = new Persistencia();
            ResultSet rs = base.consultaSQL("SELECT * from usuarios WHERE usuario = " + "'" + 
            request.getParameter("inputEmail") + "'" + " and clave = " + "'" + 
            request.getParameter("inputPassword")+ "'");
                                      
            while(rs.next()){
                out.println(rs.getString("usuario"));
                out.println(rs.getString("nombreyapellido") + "<br>");
                out.println("<h1>Proyecto: " + request.getContextPath() + "</h1>");
                out.println("<h1>Usuario: " + request.getParameter("inputEmail") + "</h1>");
            }                 
                
            if (rs.first() == false){
                out.println("No hay usuarios que coincidan con la búsqueda");
                out.println("<h1>Proyecto: " + request.getContextPath() + "</h1>");
                out.println("<h1>Usuario: " + request.getParameter("inputEmail") + "</h1>"); 
            }                          
                   
        } catch (SQLException ex){
            Logger.getLogger(checkuser.class.getName()).log(Level.SEVERE,null,ex);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(checkuser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(checkuser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
